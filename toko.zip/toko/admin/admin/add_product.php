<?php
include "../conection/connection.php";  // Koneksi ke database

// Cek apakah form di-submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['productName'];
    $price = $_POST['productPrice'];

    // Upload gambar
    $image = $_FILES['productImage']['name'];
    $target = "../../img/" . basename($image);
    
    if (move_uploaded_file($_FILES['productImage']['tmp_name'], $target)) {
        // Simpan produk ke database
        $stmt = $mysqli->prepare("INSERT INTO products (name, price, image) VALUES (?, ?, ?)");
        $stmt->bind_param('sds', $name, $price, $image);
        
        if ($stmt->execute()) {
            header("Location: ../index.php?status=success");
        } else {
            header("Location: ../index.php?status=error");
        }

        $stmt->close();
    } else {
        header("Location: ../admin.php?status=upload_error");
    }
}
?>
