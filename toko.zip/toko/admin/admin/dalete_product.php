<?php
include "../conection/connection.php";  // Koneksi ke database

// Cek apakah ada ID produk yang akan dihapus
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Hapus produk dari database
    $stmt = $mysqli->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param('i', $id);

    if ($stmt->execute()) {
        header("Location: ../index.php?status=deleted");
    } else {
        header("Location: ../index.php?status=error");
    }

    $stmt->close();
}
?>
