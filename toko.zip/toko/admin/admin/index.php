<?php
include "../conection/connection.php";  // Koneksi ke database

// Ambil data produk dari database
$result = $mysqli->query("SELECT * FROM shoes WHERE id");

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Toko Sepatu</title>
    <link rel="stylesheet" href="./css/admin-styel.css">
</head>

<body>
    <header>
        <h1>Panel Admin - Toko Sepatu Online</h1>
        <nav>
            <ul>
                <li><a href="../index.php">Beranda</a></li>
                <li><a href="index.php">Kelola Produk</a></li>
            </ul>
        </nav>
    </header>

    <section id="admin">
        <h2>Tambah Produk Baru</h2>
        <form action="process/add_product.php" method="POST" enctype="multipart/form-data">
            <label for="productName">Nama Produk:</label>
            <input type="text" id="productName" name="productName" required><br>

            <label for="productPrice">Harga Produk:</label>
            <input type="number" id="productPrice" name="productPrice" required><br>

            <label for="productImage">Gambar Produk (upload):</label>
            <input type="file" id="productImage" name="productImage" required><br>

            <button type="submit">Tambah Produk</button>
        </form>

        <h2>Daftar Produk</h2>
        <table>
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Harga</th>
                    <th>Gambar</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['name']; ?></td>
                        <td>Rp <?= number_format($row['price'], 2, ',', '.'); ?></td>
                        <td><img src="../img/<?= $row['image']; ?>" alt="<?= $row['name']; ?>" width="50"></td>
                        <td><a href="process/delete_product.php?id=<?= $row['id']; ?>">Hapus</a></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </section>
    <script src="path-ke-js"></script>

</body>

</html>