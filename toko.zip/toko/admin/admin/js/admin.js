// Fungsi untuk konfirmasi penghapusan produk
function confirmDelete(productName) {
    return confirm(`Apakah Anda yakin ingin menghapus produk "${productName}"?`);
}

// Event listener untuk setiap tombol hapus produk
document.querySelectorAll('.delete-button').forEach(button => {
    button.addEventListener('click', function(event) {
        const productName = event.target.dataset.productName; // Nama produk yang akan dihapus
        if (!confirmDelete(productName)) {
            event.preventDefault(); // Batalkan penghapusan jika tidak dikonfirmasi
        }
    });
});
