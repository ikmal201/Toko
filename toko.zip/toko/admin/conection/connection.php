<?php
$host = "localhost";  // Server database
$dbase = "shoes_store";  // Nama database
$user = "root";       // Username database (sesuaikan)
$pass = "";           // Password database (sesuaikan)

// Buat koneksi
$mysqli = new mysqli($host, $user, $pass, $dbase);

// Cek koneksi
if ($mysqli->connect_error) {
    die("Koneksi gagal: " . $mysqli->connect_error);
}
?>
