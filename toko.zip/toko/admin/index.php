<?php
include "../admin/conection/connection.php";  // Koneksi ke database

// Ambil data produk dari database
$result = $mysqli->query("SELECT * FROM shoes");

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toko Sepatu Online</title>
    <link rel="stylesheet" href="./css/admin-style.css">
</head>
<body>
    <header>
        <h1>Selamat Datang di Toko Sepatu Online</h1>
        <nav>
            <ul>
                <li><a href="#home">Beranda</a></li>
                <li><a href="#products">Produk</a></li>
                <li><a href="#contact">Kontak</a></li>
            </ul>
        </nav>
    </header>

    <section id="home">
        <h2>Sepatu Terbaik untuk Keseharianmu</h2>
        <p>Kami menyediakan berbagai macam sepatu dengan kualitas terbaik dan harga terjangkau.</p>
    </section>

    <section id="products">
        <h2>Produk Terbaru</h2>
        <div class="product-list">
            <?php while($row = $result->fetch_assoc()): ?>
            <div class="product">
                <img src="../img/<?= htmlspecialchars($row['image']); ?>" alt="<?= htmlspecialchars($row['name']); ?>">
                <h3><?= htmlspecialchars($row['name']); ?></h3>
                <p>Harga: Rp <?= number_format($row['price'], 2, ',', '.'); ?></p>

                <!-- Tombol Beli Sekarang yang mengarah ke WhatsApp -->
                <?php
                $productName = htmlspecialchars($row['name']);
                $productPrice = "Rp " . number_format($row['price'], 2, ',', '.');
                $whatsappNumber = "6287863275769"; // Ganti dengan nomor WhatsApp penjual dalam format internasional

                // Pesan otomatis yang akan dikirim melalui WhatsApp
                $whatsappMessage = "Halo, saya ingin memesan produk berikut:\n\n".
                                   "Nama Produk: $productName\n".
                                   "Harga: $productPrice\n\n".
                                   "Mohon konfirmasi ketersediaan produk. Terima kasih!";
                ?>
                <a href="https://wa.me/<?= $whatsappNumber ?>?text=<?= urlencode($whatsappMessage) ?>" target="_blank">
                    <button>Beli Sekarang</button>
                </a>
            </div>
            <?php endwhile; ?>
        </div>
    </section>

    <footer id="contact">
        <h2>Kontak Kami</h2>
        <p>WhatsApp: <a href="https://wa.me/<?= $whatsappNumber ?>" target="_blank">+62 812-3456-789</a></p> <!-- Ganti dengan nomor WhatsApp -->
    </footer>

    <script src="js/script.js"></script>
</body>
</html>
